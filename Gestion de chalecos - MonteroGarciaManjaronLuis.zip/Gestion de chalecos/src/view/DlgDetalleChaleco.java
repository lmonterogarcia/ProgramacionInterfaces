package view;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.Color;
import javax.swing.JComboBox;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class DlgDetalleChaleco extends JDialog {

	private static final long serialVersionUID = 1L;
	private final JPanel contentPanel = new JPanel();
	public static JDialog ventana;
	public static JTextField txtModelo;
	public static JTextField txtPrecio;
	public static JTextField txtStock;
	public static JComboBox cbTalla;
	private JTextField txtRojo;
	private JTextField txtVerde;
	private JTextField txtAzul;
	private JTextField txtAmarillo;
	public static JLabel lblColorChaleco;

	public DlgDetalleChaleco() {
		setTitle("Detalles del Chaleco");
		ventana = this;
		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		setModal(true);
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		crearComponentes();
		
		ctrl.CtrlDlgDetalleChaleco.rellenarDatos();
		
		setVisible(true);
		
	}

	private void crearComponentes() {
		JLabel lblModelo = new JLabel("Modelo:");
		lblModelo.setBounds(24, 24, 61, 16);
		contentPanel.add(lblModelo);
		
		JLabel lblColor = new JLabel("Color:");
		lblColor.setBackground(Color.BLACK);
		lblColor.setBounds(24, 96, 38, 16);
		contentPanel.add(lblColor);
		
		JLabel lblTalla = new JLabel("Talla:");
		lblTalla.setBounds(24, 160, 61, 16);
		contentPanel.add(lblTalla);
		
		lblColorChaleco = new JLabel("Color");
		lblColorChaleco.setBounds(296, 96, 61, 16);
		contentPanel.add(lblColorChaleco);
		
		JLabel lblPrecio = new JLabel("Precio:");
		lblPrecio.setBounds(164, 160, 61, 16);
		contentPanel.add(lblPrecio);
		
		JLabel lblStock = new JLabel("Stock:");
		lblStock.setBounds(296, 160, 61, 16);
		contentPanel.add(lblStock);
		
		JButton btnGuardar = new JButton("GUARDAR");
		btnGuardar.setBounds(88, 215, 117, 29);
		contentPanel.add(btnGuardar);
		
		JButton btnCancelar = new JButton("CANCELAR");
		btnCancelar.setBounds(231, 215, 117, 29);
		contentPanel.add(btnCancelar);
		
		txtModelo = new JTextField();
		txtModelo.setBackground(Color.WHITE);
		txtModelo.setBounds(104, 14, 316, 37);
		contentPanel.add(txtModelo);
		txtModelo.setColumns(10);
		
		
		txtPrecio = new JTextField();
		txtPrecio.setBounds(216, 155, 68, 26);
		contentPanel.add(txtPrecio);
		txtPrecio.setColumns(10);
		
		txtStock = new JTextField();
		txtStock.setBounds(344, 155, 76, 26);
		contentPanel.add(txtStock);
		txtStock.setColumns(10);
		
		JComboBox cbTalla = new JComboBox(model.IChaleco.sTalla);
		cbTalla.setBounds(66, 156, 68, 27);
		contentPanel.add(cbTalla);
		
		txtRojo = new JTextField();
		txtRojo.setEditable(false);
		txtRojo.setBackground(Color.RED);
		txtRojo.setBounds(69, 89, 30, 30);
		contentPanel.add(txtRojo);
		txtRojo.setColumns(10);
		
		txtAmarillo = new JTextField();
		txtAmarillo.setEditable(false);
		txtAmarillo.setColumns(10);
		txtAmarillo.setBackground(Color.YELLOW);
		txtAmarillo.setBounds(228, 89, 30, 30);
		contentPanel.add(txtAmarillo);
		
		txtAzul = new JTextField();
		txtAzul.setEditable(false);
		txtAzul.setColumns(10);
		txtAzul.setBackground(Color.BLUE);
		txtAzul.setBounds(175, 89, 30, 30);
		contentPanel.add(txtAzul);
		
		txtVerde = new JTextField();
		txtVerde.setEditable(false);
		txtVerde.setColumns(10);
		txtVerde.setBackground(Color.GREEN);
		txtVerde.setBounds(122, 89, 30, 30);
		contentPanel.add(txtVerde);
		
		addEventos();
		
	}

	private void addEventos() {
		
		txtRojo.addActionListener( e-> ctrl.CtrlDlgDetalleChaleco.rojo());
		
	}
}
