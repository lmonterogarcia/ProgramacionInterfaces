package ctrl;

import java.sql.SQLException;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTable;

import model.Chaleco;

public class CtrlFrmPrincipal {

	public static void inicio() {

		dbms.CtrlGestConOracle.readConnectionObject();
		new view.FrmPrincipal();
		actualizar();

	}

	public static void salir() {

		int iOpcSeleccionada = JOptionPane.showConfirmDialog(null, "Desea salir?", "Asistente de salida",
				JOptionPane.YES_NO_OPTION, JOptionPane.INFORMATION_MESSAGE);
		if (iOpcSeleccionada == JOptionPane.YES_OPTION) {
			System.exit(0);

		} else if (iOpcSeleccionada == JOptionPane.NO_OPTION) {
			view.FrmPrincipal.ventana.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);

		}

	}

	public static void menuDatabase() {

		new view.DlgDatabase();
	}

	public static void menuLogin() {

		new view.DlgLogin();

	}

	public static void actualizar() {
		try {

			view.FrmPrincipal.tblChalecos.setModel(logic.LogConsultas.getListadoChalecos());
			ocultarColumna(view.FrmPrincipal.tblChalecos, 0);

		} catch (InstantiationException | IllegalAccessException | ClassNotFoundException | SQLException e) {

			e.printStackTrace();
		}

	}
	
	private static void ocultarColumna(JTable tabla, int iColumna) {
		tabla.getColumnModel().getColumn(iColumna).setMinWidth(0);
		tabla.getColumnModel().getColumn(iColumna).setMaxWidth(0);
	}

	public static void menuNuevo() {
		int iFila = view.FrmPrincipal.tblChalecos.getSelectedRow();
		new ctrl.CtrlDlgDetalleChaleco().detalleInicio(0, crearChaleco(iFila));
	}

	public static void menuEditar() {
		int iFila = view.FrmPrincipal.tblChalecos.getSelectedRow();
		new ctrl.CtrlDlgDetalleChaleco().detalleInicio(1, crearChaleco(iFila));
	}

	public static Object menuBorrar() {
		// TODO Auto-generated method stub
		return null;
	}

	public static void menuConsultar() {
		int iFila = view.FrmPrincipal.tblChalecos.getSelectedRow();
		new ctrl.CtrlDlgDetalleChaleco().detalleInicio(2, crearChaleco(iFila));
	}

	private static Chaleco crearChaleco(int iFila) {
		
		int iId = (int) view.FrmPrincipal.tblChalecos.getValueAt(iFila, 0);
		String sModelo = view.FrmPrincipal.tblChalecos.getValueAt(iFila, 1).toString();
		int iColor = 0;
		switch (view.FrmPrincipal.tblChalecos.getValueAt(iFila, 1).toString()) {
		case "Rojo":
			iColor = 0;
			break;
		case "Verde":
			iColor = 1;
			break;
		case "Azul":
			iColor = 2;
			break;
		case "Amarillo":
			iColor = 3;
			break;
		}
		
		int iTalla = 0;
		switch (view.FrmPrincipal.tblChalecos.getValueAt(iFila, 1).toString()) {
		case "S":
			iTalla = 0;
			break;
		case "M":
			iTalla = 1;
			break;
		case "L":
			iTalla = 2;
			break;
		case "XL":
			iTalla = 3;
			break;
		}
		
		double dPrecio = (double) view.FrmPrincipal.tblChalecos.getValueAt(iFila, 4);
		int iStock = (int) view.FrmPrincipal.tblChalecos.getValueAt(iFila, 5);
	
		
		return new Chaleco(iId, sModelo, iColor, iTalla, dPrecio, iStock);
		
	}

	public static void filaSeleccionada() {
		// TODO Auto-generated method stub

	}

}
