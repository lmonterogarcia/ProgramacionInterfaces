package ctrl;

import model.Chaleco;

public class CtrlDlgDetalleChaleco {

	private static int iControl, iColor;
	private static Chaleco oChaleco;

	public static void detalleInicio(int iVentanaControl, Chaleco oVentanaChaleco) {
		iControl = iVentanaControl;
		oChaleco = oVentanaChaleco;
		new view.DlgDetalleChaleco();
	};

	public static void rellenarDatos() {

		switch (iControl) {
		case 0:
			rellenarDatosNuevo();
			break;
		case 1:
			rellenarDatosEditar();
			break;
		case 2:
			rellenarDatosConsultar();
			break;
		}
	}

	private static void rellenarDatosNuevo() {
		
		rojo();
		
	}

	private static void rellenarDatosEditar() {
		

		
	}

	private static void rellenarDatosConsultar() {
		

		
	}
	
	public static void cancelar() {
		view.DlgDetalleChaleco.ventana.dispose();
	}
	
	public static void guardar() {
		switch (iControl) {
		case 0:
			Nuevo();
			break;
		case 1:
			Editar();
			break;
		}
	}

	private static void Editar() {
		
	}

	private static void Nuevo() {
		
		
	}

	public static void rojo() {
		iColor = 0;
		view.DlgDetalleChaleco.lblColorChaleco.setText("ROJO");
	}
	
	public static void verde() {
		iColor = 1;
		view.DlgDetalleChaleco.lblColorChaleco.setText("VERDE");
	}
	
	public static void azul() {
		iColor = 2;
		view.DlgDetalleChaleco.lblColorChaleco.setText("AZUL");
	}
	
	public static void amarillo() {
		iColor = 3;
		view.DlgDetalleChaleco.lblColorChaleco.setText("AMARILLO");
	}
}
