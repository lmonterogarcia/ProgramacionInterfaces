package model;

public interface IChaleco {

	public static String[] sTalla = {"S","M","L","XL"};
	public static String[] sColor = {"Rojo","Verde","Azul","Amarillo"};
}
