package model;

public interface IAlumno {

	public static String[] sTalla = {"S","M","L","XL"};
	public static String[] sSede = {"Sevilla","Pino Montano","Granada","Almeria","Malaga"};
}
